# Coding-Avengers-007
Contactless System-Advance Health management

*** About project ...!! ***

As we were trying to make a contactless system which will help the needy
patient in the emergency situation.
Our web gives the perfect and accurate information about number of beds,
number of vaccines and ventilator available in the searched hospital.

Here we have created four menu's for hospital login, user login, hospital
sign in and user sign in.
For writing the information about hospital, hospital need to register 
first to our web and then through hospital sign in they can fill the 
neccesary information about hospital and their facilities.This information
is saved to our database. Here hospital needs to update their web after 
every 24 hours, so that the regular and accurate information about available
number of bedsand vaccines is being provided.

Now for user it is neccesity that he must register to our website to avail
the benefits of our web. 
Through users sign in the users are taken to the page where all raw data 
about register hospitals is present. From there the user can search for a 
particular hospital by the city name of that hospital.This will instantly
give user the information about availability of number of beds and ventilator
along with numberof vaccines.
The correct and updated information will be available at every 24 hours.
This will help the patient members to find the right hospital which has 
availability of beds near to them.

This will reduce the time spam in searching for a hospital and will definitely
help patient in his critical situation.

*** How to run the project...!! ***

Run pip install -r requirements.txt
(This will install all neccesary modules required to run the project.)

Run python manage.py runserver in terminal.
(This will run the website in your local server.)

Now you will get the link of the server as http://127.0.0.1:8000/ .
Then copy the url and paste it in any of the browser.

Now on browser you will see the main dashboard of our website.

Or you can refer the deployed link at (" https://share-to-care.herokuapp.com ").

*** How to daownload the source-code of our web...!! ***

To download the source-code visit our github repository.
URL to repository (" https://github.com/saurabh00031/Coding-Avengers-007 ").

You can download the source-code of our web.

*** Rights and Security...!! ***

The project is developed for welfare of people in this pandemic situation.
The rights are granted to everyone accessing the project. They can develop
and modify this project.
The only condition is they should give the rights of their project to 
everyone.

" Love and kindness are never wasted... "
" Flowers always make people better, happier, and more helpful; they are 
sunshine, food and medicine to the mind. "

*** We are helping the needy ones in this covid situation. ***

You can help us by contributing to our service.
Help us financially. You can make payment on the mobile number 
(" 8623804688 ").
You can send us email for your kindness at (" jadhavsanket559@gmail.com ").

Thankyou for giving your valuable time....!

Your's sincerely,
Coding Avengers-007 team.
